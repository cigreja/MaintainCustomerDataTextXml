
package fritts.business;


public interface CustomerDAO extends CustomerReader, CustomerWriter, CustomerConstants
{
    //all methods from the CustomerReader and CustomerWriter interfaces
    //all static constants from the CustomerConstants interface
}
