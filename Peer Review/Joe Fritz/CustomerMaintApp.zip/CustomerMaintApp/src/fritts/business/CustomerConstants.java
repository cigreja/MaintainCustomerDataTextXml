
package fritts.business;

/**
 * interface to define constant NAME_SIZE
 */
public interface CustomerConstants
{
    int NAME_SIZE = 25;
}
