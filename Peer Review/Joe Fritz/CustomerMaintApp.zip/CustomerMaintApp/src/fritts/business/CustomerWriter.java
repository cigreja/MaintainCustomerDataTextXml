
package fritts.business;


public interface CustomerWriter
{
    boolean addCustomer(Customer c);
    boolean updateCustomer(Customer c);
    boolean deleteCustomer(Customer c);    
}
